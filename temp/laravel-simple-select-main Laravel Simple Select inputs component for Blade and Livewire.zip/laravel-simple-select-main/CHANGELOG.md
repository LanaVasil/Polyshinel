# Changelog

All notable changes to `laravel-simple-select` will be documented in this file

## v1.5.0 - 2023-02-14

- Added support for Laravel 10 by @laravel-shift in #14
- 
## v1.4.0 - 2022-02-09

- Added support for Laravel 9 by @dcblogdev in #7
  
## v1.3.0 - 2022-01-29

- Added TailwindCSS Dark Mode support.
  
## v1.2.5 - 2021-11-21

- Fixed bugs in usage of integer as field value.
  
## v1.2.4 - 2021-11-12

- Added default value for `id` prop.
  
## v1.2.3 - 2021-08-11

- `customSelected` Slot Bug fix.
  
## v1.2.2 - 2021-08-04

- Popper positioning bug fix
  
## v1.2.1 - 2021-07-26

- wire:model and popper bug fix.
  
## v1.2.0 - 2021-06-26

- Added `customSelected` Slot.
  
## v1.1.2 - 2021-06-26

- Fix bugs in `:clearable` props.
  
## v1.1.1 - 2021-06-26

- Added `:clearable` prop.

## v1.0.6 - 2021-06-26

- Updated `README.md`

## v1.0.5 - 2021-06-25

- Fix bugs in :value props.
  
## v1.0.4 - 2021-06-25

- Added demo.gif image preview to  `README.md`

## v1.0.3 - 2021-06-25

- Bug fix.

## v1.0.2 - 2021-06-25

- Bug fix.

## v1.0.1 - 2021-06-25

- Bug fix.

## v1.0.0 - 2021-06-25

- Major release

## v0.1.1 - 2021-06-24

- initial release bug fix.
  
## v0.1.0 - 2021-06-24

- initial release
