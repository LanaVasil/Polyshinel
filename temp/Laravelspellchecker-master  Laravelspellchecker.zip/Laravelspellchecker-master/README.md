https://laravelspellchecker.herokuapp.com


routes: /check
