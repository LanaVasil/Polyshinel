## Livewire Select demo

Laravel app showcasing asantibanez/livewire-select component

## Preview

![preview](https://github.com/asantibanez/livewire-select-demo/raw/master/preview.gif)

## Usage

Clone the repository, install dependencies, run migrations and seeders

## License

Open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
