<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CarCity extends Model
{
    protected $guarded = [];
}
