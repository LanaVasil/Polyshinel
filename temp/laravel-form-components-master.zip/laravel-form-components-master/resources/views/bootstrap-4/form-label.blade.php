@if($label)
    <label {!! $attributes !!}>{{ $label }}</label>
@endif