<span {!! $attributes->merge(['class' => 'input-group-text']) !!}>{!! $slot !!}</span>
