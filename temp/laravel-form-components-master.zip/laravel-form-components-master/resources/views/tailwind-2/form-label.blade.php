@if($label)
    <span {!! $attributes->merge(['class' => 'text-gray-700']) !!}>{{ $label }}</span>
@endif