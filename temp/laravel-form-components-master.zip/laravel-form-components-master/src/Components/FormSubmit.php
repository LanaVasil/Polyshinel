<?php

namespace ProtoneMedia\LaravelFormComponents\Components;

class FormSubmit extends Component
{
}
