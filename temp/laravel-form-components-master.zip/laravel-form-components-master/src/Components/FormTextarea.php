<?php

namespace ProtoneMedia\LaravelFormComponents\Components;

class FormTextarea extends FormInput
{
}
