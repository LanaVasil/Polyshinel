<?php

namespace LaravelAdminExt\Select2;

use Encore\Admin\Extension;

class Select2 extends Extension
{
    public $name = 'select2';
    public $views = __DIR__ . '/../resources/views';
}
