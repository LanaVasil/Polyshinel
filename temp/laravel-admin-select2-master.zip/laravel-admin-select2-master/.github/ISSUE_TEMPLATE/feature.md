---
name: Feature request
about: request a new feature
title: ''
labels: feature
assignees: ''

---

**Feature description**

I want ....

**Design graph or prototype**

If has, upload here. or delete this statement.

**Additional statement**

....